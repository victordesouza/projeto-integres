<?php
require_once("cabecalho.php");

echo $_POST['descricao']."<br>".$_POST['unPeso']."<br>".$_POST['unMedida']."<br>".$_POST['largura1']."<br>".$_POST['ncm'];

?>
