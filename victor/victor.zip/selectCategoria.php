<?php
require_once("cabecalho.php");

?>
http://rafaelcouto.com.br/consulta-interativa-sem-refresh-com-ajax/
